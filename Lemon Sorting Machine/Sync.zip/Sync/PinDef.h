#include <WiFi.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 20, 4);

#include <Firebase_ESP_Client.h>

//Provide the token generation process info.
#include "addons/TokenHelper.h"
//Provide the RTDB payload printing info and other helper functions.
#include "addons/RTDBHelper.h"

// Insert your network credentials
#define WIFI_SSID "REPLACE_WITH_YOUR_SSID"
#define WIFI_PASSWORD "REPLACE_WITH_YOUR_PASSWORD"

// Insert Firebase project API Key
#define API_KEY "REPLACE_WITH_YOUR_FIREBASE_PROJECT_API_KEY"

// Insert RTDB URLefine the RTDB URL */
#define DATABASE_URL "REPLACE_WITH_YOUR_FIREBASE_DATABASE_URL"

//Define Firebase Data object
FirebaseData fbdo;

FirebaseAuth auth;
FirebaseConfig config;

unsigned long sendDataPrevMillis = 0;
int count = 0;
bool signupOK = false;


const int VOLTAGE_SENSOR_PIN_1 = 32;
const int VOLTAGE_SENSOR_PIN_2 = 33;
const int CURRENT_SENSOR_PIN_1 = 34;
const int CURRENT_SENSOR_PIN_2 = 35;

const int INPUT_PIN_1 = 19;
const int INPUT_PIN_2 = 18;
const int INPUT_PIN_3 = 5;
const int INPUT_PIN_4 = 4;

const int OUTPUT_PIN_1 = 25;
const int OUTPUT_PIN_2 = 26;
const int OUTPUT_PIN_3 = 27;
const int OUTPUT_PIN_4 = 14;

float Voltage_1, Voltage_2, Current_1, Current_2;

// Floats for resistor values in divider (in ohms)
float R1 = 30000.0;
float R2 = 7500.0;